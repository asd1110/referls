package com.wipro.carrental.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.wipro.carrental.bean.CarBookingBean;
import com.wipro.carrental.util.DBUtil;

public class CarBookingDAO {

	public boolean bookACar(CarBookingBean bean){
		try{
			Connection con=DBUtil.getDBConn();
			PreparedStatement ps=con.prepareStatement("insert into CAR_BOOKING_TBL values(?,?,?,?,?)");
			ps.setString(1, bean.getBookingId());
			java.util.Date d=new java.util.Date();
			ps.setDate(2, new Date(bean.getDateOfHire().getTime()));
			ps.setString(3, bean.getCarType());
			ps.setString(4, bean.getCustomerName());
			ps.setString(5, bean.getPhoneNumber());
			ps.execute();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	
	/*private String date(java.util.Date dateOfHire) {
		String mon="";
		switch (dateOfHire.getMonth()) {
		case 1:
			
			break;

		default:
			break;
		}
		return null;
	}*/

	public boolean cancelACar(String bookingId){
		try{
		Statement st=DBUtil.getDBConn().createStatement();
		int b=st.executeUpdate("delete from CAR_BOOKING_TBL where Booking_ID='"+bookingId+"'");
		if(b<=0){
			return false;
		}
		else{
			return true;
		}
		}
		catch (Exception e) {
			return false;
		}
	}
	
	public int findBookedCarsByDate (java.util.Date hireDate,String carType){
		try{
		String sql="select No_of_cars_Available from CAR_TBL join CAR_BOOKING_TBL using(Car_Type) where Car_Type=? and Date_of_hire=?";
		PreparedStatement ps=DBUtil.getDBConn().prepareStatement(sql);
		ps.setString(1, carType);
		ps.setDate(2, new Date(hireDate.getTime()));
		ResultSet rs=ps.executeQuery();
		rs.next();
		return rs.getInt(1);
		}
		catch (Exception e) {
			return 0;
		}
	}
	
	
	public int getAvailableCars(String cartype){
		try{
			Statement st=DBUtil.getDBConn().createStatement();
			String sql="select No_of_cars_Available from CAR_TBL where Car_Type='"+cartype+"'";
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			return rs.getInt(1);
			}
			catch (Exception e) {
				return 0;
			}
	}
	
	public String getBookingID(String carType){
		try{
			String s="";
		Statement st=DBUtil.getDBConn().createStatement();
		String sql="select Carbooking_sequence.NEXTVAL from dual";
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()){
		s= carType.substring(0,2)+rs.getInt(1);
		}
		return s; 
		}
		catch (Exception e) {
			return e.toString();
		}
	}
}
