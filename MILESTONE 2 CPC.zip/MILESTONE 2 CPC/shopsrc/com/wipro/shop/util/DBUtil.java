package com.wipro.shop.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil 
{
	 private static Connection con=null;
		
	
		public static Connection getDBConnection()
		{
				 String driverName="oracle.jdbc.OracleDriver";
				 String url="jdbc:oracle:thin:@localhost:1521:ORCL";
				 String username="B44576767563";
				 String password="B44576767563";
					try
				{
					Class.forName(driverName);
					con=DriverManager.getConnection(url,username,password);
				}
				catch(ClassNotFoundException e)
				{
					e.printStackTrace();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
				return con;
				
		}	
		
}



