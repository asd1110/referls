package com.wipro.shop.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.wipro.shop.bean.CouponBean;
import com.wipro.shop.bean.ItemBean;
import com.wipro.shop.dao.CouponDAO;
import com.wipro.shop.dao.ItemDAO;
import com.wipro.shop.util.DBUtil;
import com.wipro.shop.util.NoSuchCouponException;

public class ShoppingMain 
{
	

	public String doShopping(String itemCode,String userID, String couponCode)
	{
		if(itemCode==null||userID==null||couponCode==null)
		{
			return "NULL VALUE";
		}
		
		ItemDAO idao=new ItemDAO();
		ItemBean str=idao.findItemByItemCode(itemCode);		
		if(str==null)
		{
			return "INVALID ITEM CODE";
		}
		
		
		CouponDAO cdao=new CouponDAO();
		CouponBean cb;
		cb=cdao.findCouponByCouponCode(couponCode);
		
		if(cb==null)
		{
			try
			{
				throw new NoSuchCouponException();
			}
			catch (NoSuchCouponException e) 
			{
				return "INVALID COUPON CODE";
			}
		}
		
		cb=cdao.findCouponByUserID(userID);
		if(cb==null)
		{
			return "DATA MISMATCH";
		}
		
		if(cb.getStatus()==0)
		{
			return "USED COUPON";
		}
		
		return null;
		
	}
	
	public List<ItemBean> viewAllItems()
	{
		List<ItemBean> l=new ArrayList<ItemBean>();
		
		return l;
	}
	public static void main(String[] args) 
	{
		ShoppingMain shopping = new ShoppingMain();
		
        List<ItemBean> listItems = shopping.viewAllItems();
       
        // Do Shopping
        String itemCode = "TI1000";
        String userID = "AA1000";
        String couponCode = "AB10CD20";
       
        String result = shopping.doShopping(itemCode, userID, couponCode);
        System.out.println(result);
	}

}
