package com.wipro.candidate.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;

public class CandidateDAO {
	Connection con=DBUtil.getDBConn();

	public String addCandidate(CandidateBean CandidateBean){
		String result="";
		try {
			PreparedStatement ps=con.prepareStatement("insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)");
			ps.setString(1,CandidateBean.getId());
			ps.setString(2,CandidateBean.getName());
			ps.setInt(3,CandidateBean.getM1());
			ps.setInt(4,CandidateBean.getM2());
			ps.setInt(5,CandidateBean.getM3());
			ps.setString(6,CandidateBean.getResult());
			ps.setString(7,CandidateBean.getGrade());
			int b=ps.executeUpdate();
			if(b>0)
			result="SUCCESS";
			else
				result="FAIL";
			
		} catch (SQLException e) {
			System.out.println("result "+e.toString());
			result="FAIL";
		}
		return result;
		
	}


public ArrayList<CandidateBean>getByResult(String criteria){
	PreparedStatement st=null;
	ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
	try {
		ResultSet res=null;
		if(criteria.equals("ALL")){
		String query="select * from CANDIDATE_TBL";
		st=con.prepareStatement(query);
		res=st.executeQuery();
		while(res.next()){
			CandidateBean cbean=new CandidateBean();
			cbean.setId(res.getString(1));
			cbean.setName(res.getString(2));
			cbean.setM1(res.getInt(3));
			cbean.setM2(res.getInt(4));
			cbean.setM3(res.getInt(5));
			cbean.setResult(res.getString(6));
			cbean.setGrade(res.getString(7));
			list.add(cbean);
		}
	}else if((criteria.equals("PASS")) || (criteria.equals("FAIL"))){
		String query="select * from CANDIDATE_TBL where result=?";
		st=con.prepareStatement(query);
		st.setString(1, criteria);
		res=st.executeQuery();
		while(res.next()){
			CandidateBean cbean=new CandidateBean();
			cbean.setId(res.getString(1));
			cbean.setName(res.getString(2));
			cbean.setM1(res.getInt(3));
			cbean.setM2(res.getInt(4));
			cbean.setM3(res.getInt(5));
			cbean.setResult(res.getString(6));
			cbean.setGrade(res.getString(7));
			list.add(cbean);
			
		}
	}else{
		list=null;
	}
		
	}catch (SQLException e) {
		System.out.println("list "+e.toString());
		list=null;
	}
	
	
	return list;
	
}

public String generateCandidateId(String name){
	String q="select CANDID_SEQ.NEXTVAL from dual";
	Statement st;
	String result="";
	try {
		st = con.createStatement();
		ResultSet rs=st.executeQuery(q);
		while(rs.next())
		result=name.substring(0,2).trim().toUpperCase().concat(rs.getString(1));
		System.out.println(result);
		
	} catch (SQLException e) {
		System.out.println("result "+e.toString());
	}
	
	return result;
	
}
}
