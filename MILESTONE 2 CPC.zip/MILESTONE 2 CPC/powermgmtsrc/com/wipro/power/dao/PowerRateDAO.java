package com.wipro.power.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.power.bean.PowerRateBean;
import com.wipro.power.util.DBUtil;

public class PowerRateDAO
{
	public PowerRateBean findRateByType(String type)
	{
		PowerRateBean prb =null;
		Connection con=null;
		Statement s=null;
		ResultSet rs=null;
		
		switch(type)
		{
			case "House":
				con=DBUtil.getDBConnection();
				String sql="select * from power_rate_tbl where type='House'";
				prb=new PowerRateBean();
				try
				{
					s=con.createStatement();
					
					rs=s.executeQuery(sql);
					
					while(rs.next())
					{
						prb.setSlab1(rs.getInt(1));
						prb.setSlab2(rs.getInt(2));
						prb.setSlab3(rs.getInt(3));
						prb.setSlabRate1(rs.getFloat(4));
						prb.setSlabRate2(rs.getFloat(5));
						prb.setSlabRate3(rs.getFloat(6));	
					}
					
				} 
				catch (SQLException e)
				{
					e.printStackTrace();
				}
				break;
				
			case "Shop":
				
				
				con=DBUtil.getDBConnection();
				String sql1="select * from power_rate_tbl where type='Shop'";
				prb=new PowerRateBean();
				try
				{
					s=con.createStatement();
					
					rs=s.executeQuery(sql1);
					
					while(rs.next())
					{
						prb.setSlab1(rs.getInt(1));
						prb.setSlab2(rs.getInt(2));
						prb.setSlab3(rs.getInt(3));
						prb.setSlabRate1(rs.getFloat(4));
						prb.setSlabRate2(rs.getFloat(5));
						prb.setSlabRate3(rs.getFloat(6));	
					}
					
				} 
				catch (SQLException e)
				{
					e.printStackTrace();
				}
				break;
				
			case "Mall":
				
				con=DBUtil.getDBConnection();
				String sql2="select * from power_rate_tbl where type='Mall'";
				prb=new PowerRateBean();
				try
				{
					s=con.createStatement();
					
					rs=s.executeQuery(sql2);
					
					while(rs.next())
					{
						prb.setSlab1(rs.getInt(1));
						prb.setSlab2(rs.getInt(2));
						prb.setSlab3(rs.getInt(3));
						prb.setSlabRate1(rs.getFloat(4));
						prb.setSlabRate2(rs.getFloat(5));
						prb.setSlabRate3(rs.getFloat(6));	
					}
					
				} 
				catch (SQLException e)
				{
					e.printStackTrace();
				}
				break;
		
		}
		return prb;
	}

}
