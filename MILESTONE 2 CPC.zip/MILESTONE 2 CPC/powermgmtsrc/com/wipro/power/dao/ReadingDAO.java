package com.wipro.power.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.wipro.power.bean.ReadingBean;
import com.wipro.power.util.DBUtil;

public class ReadingDAO
{
	Connection con=null;
	PreparedStatement ps=null;
	public String createReading(ReadingBean readingBean)
	{
		
		con=DBUtil.getDBConnection();
		String sql="insert into readings_tbl values(?,?,?,?,?,?,?,?,?)";
		int flag=0;
		try
		{
			flag=0;
			ps=con.prepareStatement(sql);			
			ps.setInt(1,readingBean.getSerialNo());
			ps.setString(2,readingBean.getAssetID());
			ps.setString(3,readingBean.getType());
			ps.setInt(4,readingBean.getPresentReading());
			ps.setInt(5,readingBean.getPastReading());
			ps.setString(6,readingBean.getBillMonth());
			ps.setString(7, readingBean.getBillYear());
			ps.setInt(8, readingBean.getUnitsUsed());
			ps.setFloat(9, readingBean.getAmount());
			
			ps.executeUpdate();
			flag=1;
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		if(flag==1)
		{
			return "SUCCESS";
		}
		else
		{
			return "FAIL";
		}
	}
	
	public int generateSerialNo()
	{
		int myId=0;
		String sqlIdentifier = "select serialno_seq.NEXTVAL from dual";
		PreparedStatement pst = null;
		ResultSet rs=null;
		try 
		{
			con=DBUtil.getDBConnection();
			pst = con.prepareStatement(sqlIdentifier);
			
			rs = pst.executeQuery();
			if(rs.next())
				myId = rs.getInt(1);
		} 
		catch (SQLException e) 
		{
			
		}
		 
		return myId;
	}
	
	public ArrayList<ReadingBean> viewAllBillsByMonth(String month,String year)
	{
		con=DBUtil.getDBConnection();
		String sql="select * from readings_tbl where billmonth=? and billyear=?";
		ResultSet rs=null;
		int flag=0;
		ArrayList<ReadingBean> arlist=null;
		ReadingBean rb=null;
		
		try 
		{
			ps=con.prepareStatement(sql);
			arlist=new ArrayList<ReadingBean>();
			ps.setString(1,month);
			ps.setString(2,year);
			rs=ps.executeQuery();
			while(rs.next())
			{
				rb=new ReadingBean();
				
				rb.setAmount(rs.getFloat("amount"));
				rb.setAssetID(rs.getString("assetid"));
				rb.setBillMonth(rs.getString("billmonth"));
				rb.setBillYear(rs.getString("billyear"));
				rb.setType(rs.getString("type"));
				rb.setPastReading(rs.getInt("pastreading"));
				rb.setPresentReading(rs.getInt("presentreading"));
				rb.setSerialNo(rs.getInt("serialno"));
				rb.setUnitsUsed(rs.getInt("unitsused"));
				
				arlist.add(rb);
				flag=1;
			}
		}
		catch (SQLException e)
		{
			
		}
		if(flag==1)
		{
			return arlist;
		}
		else
		{
			return null;
		}
	}

}