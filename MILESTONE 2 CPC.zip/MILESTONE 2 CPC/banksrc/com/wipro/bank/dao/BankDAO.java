package com.wipro.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.bank.bean.TransferBean;
import com.wipro.bank.util.DBUtil;

public class BankDAO {
	
	public int generateSequenceNumber(){
		int id = 0;
		Connection con=DBUtil.getDBConnection();
		String query="select transactionId_seq.nextval from dual";
		try {
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			if(rs.next()){
				id=rs.getInt(1);
			}
			else{
				id=0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return id;
		
	}
	public boolean validateAccount(String accountNumber){
		Connection con=DBUtil.getDBConnection();
		int v=0;
		String qvalid="select count(Account_Number) from account_tbl where Account_Number=?";
		try {
			PreparedStatement ps=con.prepareStatement(qvalid);
			ps.setString(1, accountNumber);
			ResultSet rs2=ps.executeQuery();
			if(rs2.next()){
				v=rs2.getInt(1);
			}
			if(v>0){
				return true;
			}
			else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
	}
	public float findBalance(String accountNumber){
		Connection con=DBUtil.getDBConnection();
		int v1=0;
		float balance=0.0f;
		String qvalid1="select count(Account_Number) from account_tbl where Account_Number=?";
		PreparedStatement ps1;
		try {
			ps1 = con.prepareStatement(qvalid1);
			ps1.setString(1,accountNumber);
			ResultSet rs3=ps1.executeQuery();
			if(rs3.next()){
				v1=rs3.getInt(1);
			}
			if(v1>0){
				String bal="select balance from account_tbl where Account_Number=?";
				PreparedStatement ps2=con.prepareStatement(bal);
				ps2.setString(1,accountNumber);
				ResultSet rs4=ps2.executeQuery();
				if(rs4.next()){
					balance=rs4.getFloat(1);
					
				}
				return balance;
			}
			else{
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
		
	}
	public boolean transferMoney(TransferBean transferBean){
		Connection con=DBUtil.getDBConnection();
		int row=0;
		Date d = null;
		int tid=generateSequenceNumber();
		String tdate="select sysdate from dual";
		Statement st;
		try {
			st = con.createStatement();
			ResultSet rsdate=st.executeQuery(tdate);
			if(rsdate.next()){
				d=rsdate.getDate(1);
			}
			
		String in="insert into transfer_tbl values(?,?,?,?,?)";
		PreparedStatement pin=con.prepareStatement(in);
		pin.setInt(1,tid);
		pin.setString(2,transferBean.getFromAccountNumber());
		pin.setString(3,transferBean.getToAccountNumber());
		pin.setDate(4,d);
		pin.setFloat(5,transferBean.getAmount());
		row=pin.executeUpdate();
		if(row>0){
			return true;
		}
		else{
			return false;
		}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return false;
		
	}
	public boolean updateBalance(String accountNumber, float newBalance){
		
		Connection con=DBUtil.getDBConnection();
		String up="update account_tbl set balance=? where account_number=?";
		PreparedStatement pup;
		try {
			pup = con.prepareStatement(up);
			pup.setFloat(1,newBalance);
			pup.setString(2,accountNumber);
			int row2=pup.executeUpdate();
			if(row2>0){
				return true;
			}
			else{
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return false;
		
	}
}
